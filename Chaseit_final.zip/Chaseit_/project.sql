set global time_zone='+2:00';
create database project;
CREATE USER 'projectcuser'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON project.* TO 'projectcuser'@'localhost';
FLUSH PRIVILEGES;
use project;

create table users(
id int auto_increment NOT NULL,
name varchar(50),
username varchar(50),
password varchar(50),
email varchar(50),
gender varchar(10),
tel int,
country varchar(50),
 PRIMARY KEY (`id`)
);


insert into users (name,username,password,email,gender,tel,country) values
("John Ellington", "john_ellington","12345678","john_ellington@yahoo.com","male","1111111111","England"),
("Mary Sparks", "mary_sparks","12345678","mary.sparks@yahoo.com","female","2222222222","Wales"),
("Paul Newman", "paul_newman","12345678","newman_paul@yahoo.com","male","3333333333","Ireland"),
("Jean Scott", "jean_scott","12345678","scott.jean@yahoo.com","female","4444444444","Scotland"),
("George White", "george_white","12345678","george_white@yahoo.com","male","5555555555","United States");

create table products(
id int auto_increment NOT NULL,
name varchar(100),
price varchar(50),
description varchar(150),
type varchar(50),
img varchar(50),
PRIMARY KEY(`id`)
);

insert into products (name,price,description,type,img) values
("Grilled beef with potatoes","$29","Meat, potatoes, rice, tomatoes","breakfast","breakfast-1.jpg"),
("Egg-plant chicken","$21", "Chicken, tomatoes, eggplant, babyspinach", "breakfast", "breakfast-2.jpg"),
("Banana oatmeal", "$15", "Yoghurt, oatmeal, banana, seeds", "breakfast", "breakfast-3.jpg"),
("Poached egg with avocado", "$13", "Egg, avocado, brocolli, veggies", "breakfast", "breakfast-4.jpg"),
("Sourdough chicken", "$19", "Chicken, dressing, veggies, tomatoes", "breakfast", "breakfast-5.jpg"),
("Avo-toast", "$17", "Egg, avocado, onion, seeds", "breakfast", "breakfast-6.jpg"),
("Baked salmon", "$34", "Salmon, sauce, salad, tomatoes", "breakfast", "breakfast-7.jpg"),
("Strawberries oatmeal", "$13", "Oatmeal, strawberries, water, yoghurt","breakfast", "breakfast-8.jpg"),
("Cooked salmon", "$34", "Lemon, salmon, salad, tomatoes", "lunch", "lunch-1.jpg"),
("Cooked chicken", "$29", "Chicken, dressing, potatoes, tomatoes", "lunch", "lunch-2.jpg"),
("Poached chicken", "$24", "Chicken, sauce, salad, lemon", "lunch", "lunch-3.jpg"),
("Shrimp skewers", "$40", "Shrimp, sauce, babyspinach, sauce", "lunch", "lunch-4.jpg"),
("Seafood", "$40", "Shrimp, seashells, rice, garlic", "lunch", "lunch-5.jpg"),
("Grilled beef with vegetables", "$28", "Beef, potatoes, asparagus, tomatoes", "lunch", "lunch-6,jpg"),
("Broiled chicken", "$29", "Chicken, tomatoes, brocolli, mashed potatoes", "lunch" , "lunch-7.jpg"),
("Roasted chicken", "$31", "Chicken, plate, parsley, dill", "lunch", "lunch-8.jpg"), 
("Sesame chicken", "$27", "Chicken, sesame, babyspinach, dressing", "dinner", "dinner-1.jpg"),
("Ramen", "$23", "Noodles, onion, beef, carrot", "dinner", "dinner-2.jpg"),
("Vegetables omlette", "$21", "Egg, tomatoes, mushrooms, parsley", "dinner", "dinner-3.jpg"),
("Egg-plant salmon", "$33", "Salmon, egg-plant, babyspinach, tomatoes", "dinner", "dinner-4.jpg"),
("Shrimp pasta", "$35", "Pasta, shrimps, egg, dressing", "dinner", "dinner-5.jpg"),
("Avo-poached egg", "$19", "Avocado, egg,bread, seeds", "dinner", "dinner-6.jpg"),
("Margarita", "$29", "Vodka, strawberries, sugar, lime", "drinks", "drink-1.jpg"),
("Lemonade", "$14", "Lemon, lime, sugar, ice", "drinks", "drink-2.jpg"),
("Orange cocktail", "$29", "Orange, ice, alcohol, design", "drinks", "drink-3.jpg"),
("Draft beer", "$16", "Just enjoy!", "drinks", "drink-4.jpg"),
("Green apple", "$21", "Apple,lime, sugar, lime", "drinks", "drink-5.jpg"),
("Apple cocktail", "$29", "Apple, vodka, ice, lemon", "drinks", "drink-6'jpg"),
("Pancakes", "$19", "Pancakes, strawberries, caramel, chocolate", "desserts", "dessert-1.jpg"),
("Whipped strawberries", "$18", "Whipped-cream, strawberries, biscuit, honey", "desserts", "dessert-2,jpg"),
("Lava-cake", "$18", "Chocolate sauce, cinnamon, vanilla", "desserts", "dessert-3.jpg"),
("Icecream", "$17", "Chocolate, strawberries, apple, apricot", "desserts", "dessert-4,jpg"),
("Decorated icecream", "$20", "Icecream, Chocolate, strawberries, vanilla", "desserts", "dessert-5.jpg"),
("Apple cocktail", "$29", "Apple, vodka, flavour, ice", "desserts", "drink-6.jpg"),
("White wine", "$35", "Just enjoy!", "wines", "wine-1.jpg"),
("Rose wine", "$38", "Just enjoy!", "wines", "wine-2.jpg"),
("Red wine", "$41", "Just enjoy!", "wines", "wine-3.jpg"),
("White busuioaca de Bohotin", "$29", "Just enjoy!", "wines", "wine-4.jpg"),
("Rose Samburesti", "$39", "Just enjoy!", "wines", "wine-5jpg"),
("Red Cotnari", "$26", "Just enjoy!", "wines", "wine-6.jpg"),
("Prosecco", "$29", "Just enjoy!", "wines", "wine-7.jpg"),
("Moet Champagne", "$57", "Just enjoy!", "wines", "wine-8.jpg");