package dao;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import model.User;

public class UserDAO {
	private static UserDAO instance;
	List<User> users;

	public static UserDAO getInstance() {
		if (instance == null) {
			instance = new UserDAO();
		}
		return instance;
	}

	private UserDAO() {
	}

	public void getUsers() {
		users = new ArrayList<User>();
		String sql = "SELECT * FROM users";
		try (Connection connection = DBConnection.getConnection();
				PreparedStatement prepStmt = connection.prepareStatement(sql);) {
			ResultSet rs = prepStmt.executeQuery();
			while (rs.next()) {
				users.add(new User(rs.getString("name"), rs.getString("username"), rs.getString("password"),
						rs.getString("email"), rs.getString("gender"), rs.getString("tel"), rs.getString("country")));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

	}

	public Map<String, String> userExists(String username, String email, String tel) {
		Map<String, String> errors = new LinkedHashMap<String, String>();
		for (User p : users) {
			if (p.getUsername() != null && p.getUsername().equals(username))
				errors.put("username", "User already exists!");
			if (p.getEmail() != null && p.getEmail().equals(email))
				errors.put("email", "Email already exists!");
			if (p.getTel() != null && p.getTel().equals(tel))
				errors.put("tel", "Phone number already exists!");
		}
		return errors;
	}

	public Map<String, String> logInValidation(String username, String password) {
		Map<String, String> errors = new LinkedHashMap<String, String>();
		boolean userFound = false;
		for (User p : users) {
			if (p.getUsername().equals(username)) {
				userFound = true;
				if (!p.getPassword().equals(password)) {
					errors.put("password", "Password is incorect!");
				}
				break;
			}
		}
		if (!userFound)
			errors.put("uname", "Wrong username!");
		return errors;
	}

	public void saveUser(User u) {
		String sql = "INSERT INTO users (name,username,password,email,gender,tel,country) VALUES (?,?,?,?,?,?,?)";
		try (Connection connection = DBConnection.getConnection();
				PreparedStatement prepStmt = connection.prepareStatement(sql);) {
			prepStmt.setString(1, u.getName());
			prepStmt.setString(2, u.getUsername());
			prepStmt.setString(3, getHash(u.getPassword()));
			prepStmt.setString(4, u.getEmail());
			prepStmt.setString(5, u.getGender());
			prepStmt.setString(6, u.getTel());
			prepStmt.setString(7, u.getCountry());
			prepStmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public String getHash(String password) {
		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException ex) {
			ex.printStackTrace();
		}
		digest.reset();
		try {
			digest.update(password.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException ex) {
			ex.printStackTrace();
		}
		return new BigInteger(1, digest.digest()).toString(16);
	}

}
