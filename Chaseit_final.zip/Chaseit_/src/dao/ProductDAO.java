package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dao.DBConnection;
import model.Product;

public class ProductDAO {
	private static ProductDAO instance;

	public static ProductDAO getInstance() {

		if (instance == null) {
			instance = new ProductDAO();
		}

		return instance;

	}

	public ProductDAO() {
	}

	public Product find(String id) throws NumberFormatException, SQLException {
		return find(Integer.valueOf(id));
	}

	public Product find(int id) throws SQLException {
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where id=" + id;

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		rs.next();
		Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"), rs.getString("image"));

		return p;
	}

	public List<Product> getProductList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getString("name"), rs.getString("price"));
			products.add(p);
		}
		return products;
	}

	public List<Product> getProductBreakfastList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where type='breakfast'";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"),rs.getString("image"));
			products.add(p);
		}
		return products;
	}
	
	public List<Product> getProductLunchList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where type='lunch'";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"),rs.getString("image"));
			products.add(p);
		}
		return products;
	}

	public List<Product> getProductDinnerList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where type='dinner'";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"),rs.getString("image"));
			products.add(p);
		}
		return products;
	}
	
	public List<Product> getProductDessertsList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where type='desserts'";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"),rs.getString("image"));
			products.add(p);
		}
		return products;
	}
	
	public List<Product> getProductDrinksList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where type='drinks'";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"),rs.getString("image"));
			products.add(p);
		}
		return products;
	}
	
	public List<Product> getProductWinesList() throws SQLException {

		List<Product> products = new ArrayList<>();
		Connection con = DBConnection.getConnection();
		Statement instr = (Statement) con.createStatement();

		String sql = "select * from products where type='wines'";

		ResultSet rs = ((java.sql.Statement) instr).executeQuery(sql);
		while (rs.next()) {
			Product p = new Product(rs.getInt("id"), rs.getString("name"), rs.getString("price"), rs.getString("description"), rs.getString("type"),rs.getString("image"));
			products.add(p);
		}
		return products;
	}
	
	
	public Object findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
