package controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.CartProduct;

/**
 * Servlet implementation class BuyController
 */
@WebServlet("/BuyController")
public class BuyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean pexist=false;
		// TODO Auto-generated method stub
		List<CartProduct> Cart=(List<CartProduct>) request.getSession().getAttribute("cart");
		String image=request.getParameter("image");
		String name=request.getParameter("name");
		String description=request.getParameter("description");
		String type=request.getParameter("type");
		int id=request.getIntHeader("id");
		String price=request.getParameter("price");
		
		CartProduct p=new CartProduct(id, name, price, description, type, image);
		System.out.println(p.getImage());
		for (CartProduct crtp:Cart) {
			
			if(crtp.getName().contentEquals(p.getName())) {
				pexist=true;
				break;
			}
		}
		if(pexist=false) {
			Cart.add(p);
		}
		
		request.getSession().setAttribute("cart", Cart);
		response.sendRedirect("menu.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
