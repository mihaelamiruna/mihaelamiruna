create database project;
CREATE USER 'projectcuser'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON project.* TO 'projectcuser'@'localhost';
FLUSH PRIVILEGES;
use project;

create table users(
id int auto_increment NOT NULL,
name varchar(50),
username varchar(50),
password varchar(50),
email varchar(50),
gender varchar(10),
tel int,
country varchar(50),
 PRIMARY KEY (`id`)
);


insert into users values
("John Ellington", "john_ellington","12345678","john_ellington@yahoo.com","male","1111111111","England"),
("Mary Sparks", "mary_sparks","12345678","mary.sparks@yahoo.com","female","2222222222","Wales"),
("Paul Newman", "paul_newman","12345678","newman_paul@yahoo.com","male","3333333333","Ireland"),
("Jean Scott", "jean_scott","12345678","scott.jean@yahoo.com","female","4444444444","Scotland"),
("George White", "george_white","12345678","george_white@yahoo.com","male","5555555555","United States");