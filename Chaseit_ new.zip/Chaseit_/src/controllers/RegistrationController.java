package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;
import model.User;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
 public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Enumeration<String> attrs =  request.getParameterNames();
		User u = new User(request.getParameter("name"),request.getParameter("username"),request.getParameter("password"),request.getParameter("email"),
				request.getParameter("gender"),request.getParameter("tel"),request.getParameter("country"));
		UserDAO users = UserDAO.getInstance();
		/*users.getUsers();
		Map<String,String> errors = users.userExists(u.getUsername(), u.getEmail(), u.getTel());
		if(!errors.isEmpty()) {
			request.setAttribute("errors", errors);
			while(attrs.hasMoreElements()) {
				String id = attrs.nextElement();					
				request.setAttribute(id, request.getParameter(id));
			}
			request.getRequestDispatcher("registration.jsp").forward(request, response);
		}else {*/
			users.saveUser(u);
			request.getRequestDispatcher("login.jsp").forward(request, response);
		//}
		
		
	}

} 
